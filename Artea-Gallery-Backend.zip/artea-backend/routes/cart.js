const express = require('express');
const router = express.Router();
const { v4: uuid } = require('uuid');
const db = require('../db/database');
const auth = require('../middleware/auth');

// GET /api/cart
router.get('/', auth, (req, res) => {
  const items = db.prepare(`
    SELECT c.id as cartId, a.id, a.title, a.artist_name as artist,
           a.price, a.emoji, a.image_path, a.status, a.category
    FROM cart c JOIN artworks a ON c.artwork_id = a.id
    WHERE c.user_id = ?
  `).all(req.user.id);
  res.json(items.map(i => ({
    ...i,
    image: i.image_path ? '/uploads/' + i.image_path : null,
    image_path: undefined
  })));
});

// POST /api/cart/:artworkId
router.post('/:artworkId', auth, (req, res) => {
  const art = db.prepare('SELECT * FROM artworks WHERE id=? AND status=?').get(req.params.artworkId, 'available');
  if (!art) return res.status(404).json({ error: 'Artwork not available' });
  const exists = db.prepare('SELECT id FROM cart WHERE user_id=? AND artwork_id=?').get(req.user.id, req.params.artworkId);
  if (exists) return res.status(409).json({ error: 'Already in cart' });
  db.prepare('INSERT INTO cart (id,user_id,artwork_id) VALUES (?,?,?)').run(uuid(), req.user.id, req.params.artworkId);
  res.json({ success: true });
});

// DELETE /api/cart/:artworkId
router.delete('/:artworkId', auth, (req, res) => {
  db.prepare('DELETE FROM cart WHERE user_id=? AND artwork_id=?').run(req.user.id, req.params.artworkId);
  res.json({ success: true });
});

// DELETE /api/cart (clear all)
router.delete('/', auth, (req, res) => {
  db.prepare('DELETE FROM cart WHERE user_id=?').run(req.user.id);
  res.json({ success: true });
});

module.exports = router;
