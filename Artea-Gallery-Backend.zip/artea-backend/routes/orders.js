const express = require('express');
const router = express.Router();
const { v4: uuid } = require('uuid');
const db = require('../db/database');
const auth = require('../middleware/auth');

// POST /api/orders - place order
router.post('/', auth, (req, res) => {
  try {
    const { items, shipping, shipName, shipAddress, shipCountry, payMethod } = req.body;
    if (!items || !items.length) return res.status(400).json({ error: 'No items' });

    // Verify all items are available
    for (const item of items) {
      const art = db.prepare('SELECT status FROM artworks WHERE id=?').get(item.id);
      if (!art || art.status !== 'available') return res.status(400).json({ error: 'Item no longer available: ' + item.id });
    }

    const total = items.reduce((s, i) => s + i.price, 0) + (shipping || 45);
    const orderId = 'AEG-' + Math.floor(100000 + Math.random() * 900000);

    db.prepare('INSERT INTO orders (id,user_id,total,shipping,ship_name,ship_address,ship_country,pay_method) VALUES (?,?,?,?,?,?,?,?)')
      .run(orderId, req.user.id, total, shipping||45, shipName||null, shipAddress||null, shipCountry||null, payMethod||'Square');

    const insItem = db.prepare('INSERT INTO order_items (id,order_id,artwork_id,price) VALUES (?,?,?,?)');
    const markSold = db.prepare('UPDATE artworks SET status=? WHERE id=?');
    const delCart  = db.prepare('DELETE FROM cart WHERE user_id=? AND artwork_id=?');

    const finalize = db.transaction(() => {
      for (const item of items) {
        insItem.run(uuid(), orderId, item.id, item.price);
        markSold.run('sold', item.id);
        delCart.run(req.user.id, item.id);
      }
    });
    finalize();

    res.json({ success: true, orderId, total });
  } catch(e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

// GET /api/orders - user's order history
router.get('/', auth, (req, res) => {
  const orders = db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC').all(req.user.id);
  res.json(orders);
});

module.exports = router;
