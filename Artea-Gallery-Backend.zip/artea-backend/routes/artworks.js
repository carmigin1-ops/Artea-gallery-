const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { v4: uuid } = require('uuid');
const db = require('../db/database');
const auth = require('../middleware/auth');

// Multer config - store images
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, uuid() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['.jpg','.jpeg','.png','.gif','.webp'];
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, allowed.includes(ext));
  }
});

// GET /api/artworks - list all
router.get('/', (req, res) => {
  const { category, search, status } = req.query;
  let sql = 'SELECT * FROM artworks WHERE 1=1';
  const params = [];
  if (category && category !== 'All') { sql += ' AND category=?'; params.push(category); }
  if (search) { sql += ' AND (title LIKE ? OR artist_name LIKE ?)'; params.push('%'+search+'%','%'+search+'%'); }
  if (status) { sql += ' AND status=?'; params.push(status); }
  sql += ' ORDER BY created_at DESC';
  const rows = db.prepare(sql).all(...params);
  res.json(rows.map(r => ({
    id: r.id, title: r.title, artist: r.artist_name, artistId: r.artist_id,
    category: r.category, price: r.price, dims: r.dims, year: r.year,
    status: r.status, emoji: r.emoji,
    image: r.image_path ? '/uploads/' + r.image_path : null,
    desc: r.description, loc: r.location, createdAt: r.created_at
  })));
});

// GET /api/artworks/:id
router.get('/:id', (req, res) => {
  const r = db.prepare('SELECT * FROM artworks WHERE id=?').get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Not found' });
  res.json({
    id: r.id, title: r.title, artist: r.artist_name, artistId: r.artist_id,
    category: r.category, price: r.price, dims: r.dims, year: r.year,
    status: r.status, emoji: r.emoji,
    image: r.image_path ? '/uploads/' + r.image_path : null,
    desc: r.description, loc: r.location
  });
});

// POST /api/artworks - create (Artist/Admin)
router.post('/', auth, upload.single('image'), (req, res) => {
  try {
    if (req.user.role !== 'Artist' && req.user.role !== 'Admin')
      return res.status(403).json({ error: 'Artists only' });
    const { title, category, price, dims, description } = req.body;
    if (!title || !price) return res.status(400).json({ error: 'Title and price required' });
    const user = db.prepare('SELECT name FROM users WHERE id=?').get(req.user.id);
    const id = uuid();
    const imagePath = req.file ? req.file.filename : null;
    db.prepare(`INSERT INTO artworks (id,title,artist_id,artist_name,category,price,dims,year,status,image_path,description)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, title, req.user.id, user.name, category||'Painting', parseFloat(price),
         dims||null, new Date().getFullYear(), 'available', imagePath, description||null);
    res.json({ success: true, id });
  } catch(e) { console.error(e); res.status(500).json({ error: 'Server error' }); }
});

// PUT /api/artworks/:id - update (Artist owns it or Admin)
router.put('/:id', auth, (req, res) => {
  try {
    const art = db.prepare('SELECT * FROM artworks WHERE id=?').get(req.params.id);
    if (!art) return res.status(404).json({ error: 'Not found' });
    if (req.user.role !== 'Admin' && art.artist_id !== req.user.id)
      return res.status(403).json({ error: 'Forbidden' });
    const { title, price, category, dims, description, status, year } = req.body;
    db.prepare(`UPDATE artworks SET title=COALESCE(?,title), price=COALESCE(?,price),
      category=COALESCE(?,category), dims=COALESCE(?,dims), description=COALESCE(?,description),
      status=COALESCE(?,status), year=COALESCE(?,year) WHERE id=?`)
    .run(title||null, price?parseFloat(price):null, category||null, dims||null,
         description||null, status||null, year?parseInt(year):null, req.params.id);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: 'Server error' }); }
});

// DELETE /api/artworks/:id (Admin only)
router.delete('/:id', auth, (req, res) => {
  if (req.user.role !== 'Admin') return res.status(403).json({ error: 'Admin only' });
  db.prepare('DELETE FROM artworks WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
