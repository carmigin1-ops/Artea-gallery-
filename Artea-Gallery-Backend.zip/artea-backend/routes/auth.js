const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const db = require('../db/database');

const SECRET = process.env.JWT_SECRET || 'artea-secret-2025';
const ADMIN_EMAIL = 'carmigin1@gmail.com';

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, payoutTab,
            bankName, bankBranch, bankAccnum, bankAcctype, bankCode,
            bankAddr, bankCity, bankZip, bankCountry, bankIdType, bankIdNum,
            gcashName, gcashNum, gcashType, gcashId, gcashIdnum, bio } = req.body;

    if (!name || !email || !password) return res.status(400).json({ error: 'Missing required fields' });

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    const hash = await bcrypt.hash(password, 10);
    const id = uuid();
    const userRole = email.toLowerCase() === ADMIN_EMAIL ? 'Admin' : (role || 'Collector');

    db.prepare(`INSERT INTO users (id,name,email,password,role,payout_tab,
      bank_name,bank_branch,bank_accnum,bank_acctype,bank_code,bank_addr,bank_city,bank_zip,bank_country,bank_id_type,bank_id_num,
      gcash_name,gcash_num,gcash_type,gcash_id,gcash_idnum,bio)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, name, email.toLowerCase(), hash, userRole, payoutTab||'bank',
         bankName||null, bankBranch||null, bankAccnum||null, bankAcctype||null, bankCode||null,
         bankAddr||null, bankCity||null, bankZip||null, bankCountry||null, bankIdType||null, bankIdNum||null,
         gcashName||null, gcashNum||null, gcashType||null, gcashId||null, gcashIdnum||null, bio||null);

    const token = jwt.sign({ id, email: email.toLowerCase(), role: userRole }, SECRET, { expiresIn: '30d' });
    res.json({ token, user: { id, name, email: email.toLowerCase(), role: userRole } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing email or password' });

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, SECRET, { expiresIn: '30d' });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/auth/profile  (update profile)
router.put('/profile', require('../middleware/auth'), async (req, res) => {
  try {
    const { name, email, password, bankName, bankAccnum, gcashNum } = req.body;
    const userId = req.user.id;

    let updates = [];
    let values = [];

    if (name) { updates.push('name=?'); values.push(name); }
    if (email) { updates.push('email=?'); values.push(email.toLowerCase()); }
    if (password) {
      const hash = await bcrypt.hash(password, 10);
      updates.push('password=?'); values.push(hash);
    }
    if (bankName)   { updates.push('bank_name=?');   values.push(bankName); }
    if (bankAccnum) { updates.push('bank_accnum=?');  values.push(bankAccnum); }
    if (gcashNum)   { updates.push('gcash_num=?');    values.push(gcashNum); }

    if (updates.length) {
      values.push(userId);
      db.prepare(`UPDATE users SET ${updates.join(',')} WHERE id=?`).run(...values);
    }

    const updated = db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(userId);
    res.json({ user: updated });
  } catch (e) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
