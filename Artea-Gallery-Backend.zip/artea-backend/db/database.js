const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, 'artea.db');
const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id           TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    email        TEXT UNIQUE NOT NULL,
    password     TEXT NOT NULL,
    role         TEXT NOT NULL DEFAULT 'Collector',
    payout_tab   TEXT DEFAULT 'bank',
    bank_name    TEXT, bank_branch TEXT, bank_accnum TEXT,
    bank_acctype TEXT, bank_code TEXT, bank_addr TEXT,
    bank_city    TEXT, bank_zip TEXT, bank_country TEXT,
    bank_id_type TEXT, bank_id_num TEXT,
    gcash_name   TEXT, gcash_num TEXT, gcash_type TEXT,
    gcash_id     TEXT, gcash_idnum TEXT, bio TEXT,
    created_at   TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS artworks (
    id           TEXT PRIMARY KEY,
    title        TEXT NOT NULL,
    artist_id    TEXT NOT NULL,
    artist_name  TEXT NOT NULL,
    category     TEXT NOT NULL,
    price        REAL NOT NULL,
    dims         TEXT,
    year         INTEGER,
    status       TEXT DEFAULT 'available',
    emoji        TEXT DEFAULT '🎨',
    image_path   TEXT,
    description  TEXT,
    location     TEXT DEFAULT 'Global',
    created_at   TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id           TEXT PRIMARY KEY,
    user_id      TEXT NOT NULL,
    total        REAL NOT NULL,
    shipping     REAL NOT NULL,
    ship_name    TEXT, ship_address TEXT, ship_country TEXT,
    pay_method   TEXT, status TEXT DEFAULT 'confirmed',
    created_at   TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id         TEXT PRIMARY KEY,
    order_id   TEXT NOT NULL,
    artwork_id TEXT NOT NULL,
    price      REAL NOT NULL
  );

  CREATE TABLE IF NOT EXISTS cart (
    id         TEXT PRIMARY KEY,
    user_id    TEXT NOT NULL,
    artwork_id TEXT NOT NULL,
    added_at   TEXT DEFAULT (datetime('now'))
  );
`);

// Seed sample artworks
const count = db.prepare('SELECT COUNT(*) as c FROM artworks').get();
if (count.c === 0) {
  const ins = db.prepare('INSERT INTO artworks (id,title,artist_id,artist_name,category,price,dims,year,status,emoji,description,location) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
  const seed = db.transaction(() => {
    ins.run('art-001','Solitude in Gold','sys','Elena Marchetti','Painting',1200,'36x48"',2024,'available','🖼️','A meditation on quiet moments, rendered in warm impasto strokes.','Milan, Italy');
    ins.run('art-002','Fractured Light','sys','Kenji Nakamura','Photography',850,'24x36"',2023,'available','📷','Long-exposure cityscape capturing the transient beauty of urban light.','Tokyo, Japan');
    ins.run('art-003','Terra Memoria','sys','Amara Osei','Mixed Media',2400,'48x60"',2024,'available','🎭','Earth pigments and archival paper.','Accra, Ghana');
    ins.run('art-004','Vessel No. 7','sys','Sofia Reyes','Sculpture',3200,'18"H',2023,'available','🏺','Wheel-thrown stoneware with ash glaze.','Mexico City');
    ins.run('art-005','Digital Reverie','sys','Lucas Bernard','Digital Art',650,'4K print',2024,'sold','💻','Algorithmic composition.','Paris, France');
    ins.run('art-006','Midnight Botanicals','sys','Elena Marchetti','Drawing',920,'20x28"',2024,'available','✏️','Graphite and ink botanical study.','Milan, Italy');
  });
  seed();
}

module.exports = db;
