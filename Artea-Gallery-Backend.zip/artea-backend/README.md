# Artea Gallery Backend Server

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the server
npm start

# 3. Open app in browser
# http://localhost:3001
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/register | Create account |
| POST | /api/auth/login | Sign in |
| PUT  | /api/auth/profile | Update profile |
| GET  | /api/artworks | List all artworks |
| GET  | /api/artworks/:id | Get one artwork |
| POST | /api/artworks | Upload artwork (Artist) |
| PUT  | /api/artworks/:id | Edit artwork |
| DELETE | /api/artworks/:id | Delete artwork (Admin) |
| GET  | /api/cart | Get cart |
| POST | /api/cart/:id | Add to cart |
| DELETE | /api/cart/:id | Remove from cart |
| DELETE | /api/cart | Clear cart |
| POST | /api/orders | Place order |
| GET  | /api/orders | Order history |

## Deploy Free to Render.com

1. Push this folder to GitHub
2. Go to render.com → New Web Service
3. Connect your repo
4. Set Build Command: `npm install`
5. Set Start Command: `npm start`
6. Add Environment Variable: `JWT_SECRET=your-random-secret`
7. Deploy — get a live URL like `https://artea-gallery.onrender.com`

## Access from Android

Once deployed, update the API BASE URL in index.html:
```js
var BASE = 'https://your-app.onrender.com';
```

## Admin Login
Email: carmigin1@gmail.com  
(Any password — admin role assigned by email)
