const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'artea-secret-2025';
module.exports = function(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ error: 'No token' });
  const token = header.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch(e) { res.status(401).json({ error: 'Invalid token' }); }
};
